# CSC-240 Algorithms and Data Structures

Repo for storing application problems that are assigned for the Alma College CSC-240 Algorithms and Data Structures course.